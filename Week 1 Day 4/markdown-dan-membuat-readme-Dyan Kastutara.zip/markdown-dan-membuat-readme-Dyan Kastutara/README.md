#Dyan Kastutara
**About Me**<br>
_Saya merupakan lulusan salah satu perguruan tinggi di lampung_<br>
**About this Site**<br>
_situs ini merupakan salah satu media untuk memperkenalkan diri saya lebih jauh_<br>
**Used Tags & Sintaxes**<br>
* HTML
 * html
 * head
 * title
 * body
 * header
 * nav
 * section
 * article
 * footer
 * div
 * h1, h2, h3, h4, h5
 * a
 * dll
* Komponen CSS
 1. font-family
 2. color
 3. font-style
 4. font-weight
 5. background-image
 6. background-repeat
 7. width
 8. cursor
 9. text-align
 10. positioning
 11. dll
